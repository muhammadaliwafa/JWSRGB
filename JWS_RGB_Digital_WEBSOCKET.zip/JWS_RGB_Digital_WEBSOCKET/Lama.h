const byte row0 = 2+0*11;
const byte row1 = 2+1*11;
const byte row2 = 2+2*11;

int start_x   = 0;
int buffer_id = 0;

const int square_size = 16;
