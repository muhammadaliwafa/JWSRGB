//String info[]={
//  "Jumat ke-1, 15 Juli 2022, Ust. Jaelani",//sampai satu bulan, tampil dihari jumat, input dilakukan 1 bulan
//  "Kp. Cireundeu, Ds. Manggungsari, Kec. Rajapolah, Tasikmalaya",
//  "Matikan Alat Komunikasi di Dalam Masjid"
//};
