void notifyClients(String x) {
  ws.textAll(x);
}

void handleWebSocketMessage(void *arg, unsigned char *data, size_t len) {
  AwsFrameInfo *info = (AwsFrameInfo*)arg;
  if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
    char in[8];
    sprintf(in, "%s", data);
    uint8_t jam;
    uint8_t menit;
    int n = sscanf(in, "%d:%d", &jam, &menit);
    RtcDateTime now=Rtc.GetDateTime();
    uint16_t year = now.Year();
    uint8_t month = now.Month();
    uint8_t day = now.Day();
    Rtc.SetDateTime(RtcDateTime(year, month, day, jam, menit, 0));
    BacaRTC();
    updateJWS;
  }
}

void onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type,
             void *arg, unsigned char *data, size_t len) {
  switch (type) {
    case WS_EVT_CONNECT:
      Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
      break;
    case WS_EVT_DISCONNECT:
      Serial.printf("WebSocket client #%u disconnected\n", client->id());
      break;
    case WS_EVT_DATA:
      handleWebSocketMessage(arg, data, len);
      break;
    case WS_EVT_PONG:
    case WS_EVT_ERROR:
      break;
  }
}

void initWebSocket() {
  ws.onEvent(onEvent);
  server.addHandler(&ws);
}

String processor(const String& var){
//  Serial.println(var);
//  if(var == "STATE"){
//    if (ledState){
//      return "ON";
//    }
//    else{
//      return "OFF";
//    }
//  }
  return String();
}

void setup_websocket(){
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi..");
  }

  // Print ESP Local IP Address
  Serial.println(WiFi.localIP());

  initWebSocket();

  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html, processor);
  });

  // Start server
  server.begin();
}
